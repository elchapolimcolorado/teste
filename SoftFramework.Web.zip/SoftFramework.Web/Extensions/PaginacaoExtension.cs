﻿using SoftFramework.Core.Domain.Entidades.EntidadesGenericasSistema;
using SoftFramework.Web.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace SoftFramework.Web.Extensions
{
    public static class PaginacaoExtension
    {
       public static PagedListParameters<T> ToPagedListParameters<T>(this Paginacao paginacao, IEnumerable<GenericFilter> filtros)
       {

           return new PagedListParameters<T>(Convert.ToInt32(paginacao.page), Convert.ToInt32(paginacao.rows), paginacao.sidx, paginacao.sord,FormatarFiltros(filtros));

        }

       public static PagedListParameters<T> ToPagedListParameters<T>(this Paginacao paginacao)
       {
           return new PagedListParameters<T>(Convert.ToInt32(paginacao.page), Convert.ToInt32(paginacao.rows), paginacao.sidx, paginacao.sord, null);

       }

       private static string FormatarFiltros(IEnumerable<GenericFilter> lista)
       {
           var sb = new StringBuilder();
           var listaRetorno = new Dictionary<string, string>();

           var listaFiltrada =
               lista.Where(x => !String.IsNullOrEmpty(x.Valor) && !String.IsNullOrEmpty(x.Tipo) && !String.IsNullOrEmpty(x.Chave));

           foreach (GenericFilter item in listaFiltrada)
           {
               int i = 0;

               if (item.Tipo.ToLower().Equals("int"))
               {
                   sb.Append(item.Chave + " = " + item.Valor);
               }
               if (item.Tipo.ToLower().Equals("string"))
               {
                   sb.Append(item.Chave + ".Contains(\"" + item.Valor + "\")");
               }
               if (item.Tipo.ToLower().Equals("datetime"))
               {
                   listaRetorno.Add(item.Chave + "<=@" + i.ToString(), item.Valor);
                   i++;
               }
               if (item != listaFiltrada.Last())
               {
                   sb.Append(" AND ");
               }

           }
           return sb.ToString();
       }

    }
}