﻿using System.Web.Mvc;

namespace SoftFramework.Web.Controllers.Base
{
    public class ExternaController : Controller
    {
        //
        // GET: /Externa/

        public ActionResult Index()
        {
            return View();
        }

    }
}
