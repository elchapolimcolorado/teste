﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using System.Web.Mvc;
using System.Web.WebPages;
using AutoMapper;
using log4net.Repository.Hierarchy;
using SoftFramework.Core.Application.DTO.Produto;
using SoftFramework.Core.Application.Servicos.Contratos;
using SoftFramework.Core.Domain.Entidades.Modulos.MercadoLivre;
using SoftFramework.Core.Helper;
using SoftFramework.Core.Infra.Repositorios.Contracts;
using SoftFramework.Core.Infra.Repositorios.Contracts.Base;
using SoftFramework.Core.Infra.UnidadeDeTrabalho;
using SoftFramework.Web.Controllers.Base;
using SoftFramework.Web.Models.MercadoLivre;

namespace SoftFramework.Web.Controllers
{
    public class ProdutoController : BaseController
    {
        private readonly IProdutoService _produtoService;
        private readonly IRepositorioProduto _repositorioProduto;
        private readonly IUnidadeDeTrabalho _unidadeDeTrabalho;
        private readonly IGenericRepository<MercadoLivreApplication> _repositorioConta;
        private readonly IMercadolivreService _mercadolivreService;

        public ProdutoController(
            IProdutoService produtoService,
            IRepositorioProduto repositorioProduto,
            IUnidadeDeTrabalho unidadeDeTrabalho,
            IGenericRepository<MercadoLivreApplication> repositorioConta,
            IMercadolivreService mercadolivreService)
        {
            _produtoService = produtoService;
            _repositorioProduto = repositorioProduto;
            _unidadeDeTrabalho = unidadeDeTrabalho;
            _repositorioConta = repositorioConta;
            _mercadolivreService = mercadolivreService;
        }

        //
        // GET: /Produto/

        public ActionResult Index()
        {
            using (var uow = _unidadeDeTrabalho.GetUow())
            {
                var model = new ProdutoModel
                {
                    Itens = _repositorioProduto.ObterTodosOnde(x=>x.IdPai == null && x.Ativo, uow).Select(x => new ProdutoItemModel
                    {
                        Id = x.Id,
                        Nome = x.Nome,
                        Descricao = x.Descricao,
                        IdMercadoLivre = x.IdMercadoLivre,
                        QuantidadeProdutosRelacionados = x.ProdutosMercadoLivreFilhos.Count(a=>a.Ativo),
                        Quantidade = x.Quantidade
                    }).ToList()

                };

                return View(model);
            }
        }

        public ActionResult AssociacaoProdutos()
        {
            var model = new AssociacaoProdutosModel();

            return View(model);
        }

        private IEnumerable<SelectListItem> ObterContas()
        {
            return _repositorioConta.ListarTodos(_unidadeDeTrabalho).Select(x =>
                new SelectListItem
                {
                    Text = x.Nome,
                    Value = x.Id.ToString(CultureInfo.CurrentCulture)
                }
            );
        }

        [HttpPost]
        public JsonResult AssociacaoProdutos(AssociacaoProdutosModel model)
        {
            var dto = Mapper.Map<AssociacaoProdutosDTO>(model);
            return Processar<AssociacaoProdutoRetornoModel>(() => _produtoService.AdicionarFilhos(dto));
        }

        [HttpGet]
        public JsonResult ObterDetalhesProdutoMercadoLivre(string url)
        {
            try
            {
                var detalheProduto = _mercadolivreService.ObterDetalheProdutoMercadoLivre(url);
                var variacoes = _mercadolivreService.ObterVariacoesProduto(url);
                var model = new
                {
                    idMercadoLivre = detalheProduto.Id,
                    nome = detalheProduto.Nome,
                    quantidade = detalheProduto.Quantidade,
                    quantidadeVariacoes = variacoes.Length,
                };

                return RetornarJson(true, model);
            }
            catch (Exception ex)
            {
                Constantes.LogarErro(ex);
                throw;
            }

        }

        [HttpGet]
        public ActionResult AlterarQuantidade(int idProduto)
        {
            var produto = _repositorioProduto.ObterPorId(idProduto, _unidadeDeTrabalho);
            var model = new AtualizarVariacaoListagemModel
            {
                IdProduto = produto.Id,
                NomeProduto = produto.Nome,
                Variacoes = produto.Variacoes.Select(x=> new AtualizarVariacaoListagemItemModel
                {
                    Id = x.Id,
                    IdVariacaoMercadoLivre = x.IdVariacaoMercadoLivre,
                    Preco = Convert.ToDouble(x.Preco),
                    QuantidadeDisponivel = x.QuantidadeDisponivel,
                    CorPrincipal = x.Combinacoes.Any(c=>c.IdCombinacao == 33000)
                    ? x.Combinacoes.First(c => c.IdCombinacao == 33000).ValorNome
                    :"",
                    CorSecundaria = x.Combinacoes.Any(c => c.IdCombinacao == 43000)
                        ? x.Combinacoes.First(c => c.IdCombinacao == 43000).ValorNome
                        : "",
                    Tamanho = x.Combinacoes.Any(c => c.IdCombinacao == 63000)
                        ? x.Combinacoes.First(c => c.IdCombinacao == 63000).ValorNome
                        : ""
                })
            };

            return View(model);
        }

        [HttpPost]
        public JsonResult AtualizarQuantidadeVariacao(AtualizarQuantidadeVariacaoModel[] model)
        {
            var dto = model.Select(x => new AtualizarQuantidadeVariacaoDTO {Id = x.Id, Qtd = x.Qtd}).ToArray();
            return Processar(() => _produtoService.AtualizarQuantidadeVariacao(dto));
        }

        [HttpPut]
        public JsonResult InativarProdutoAssociado(int idProduto)
        {
            return Processar(() => _produtoService.ExcluirprodutoFilhoDaAssociacao(idProduto));
        }

        [HttpPut]
        public JsonResult InativarProdutoPai(int idProduto)
        {
            return Processar(() => _produtoService.InativarProduto(idProduto));
        }

        [HttpPut]
        public JsonResult InativarAssociacaoProdutoFilho(int idProduto)
        {
            return Processar(() => _produtoService.ExcluirprodutoFilhoDaAssociacao(idProduto));
        }
        

        [HttpGet]
        public ActionResult Editar(int idProduto)
        {
            var produto = _repositorioProduto.ObterPorId(idProduto, _unidadeDeTrabalho);
            var detalheProdutoPai = _mercadolivreService.ObterDetalheProdutoMercadoLivre(produto.IdMercadoLivre);
            var variacoesPai = _mercadolivreService.ObterVariacoesProduto(produto.IdMercadoLivre);

            var model = new AssociacaoProdutosModel
            {
                IsEdicao = true,
                Pai = new AssociacaoProdutosItemModel
                {
                    IdMercadoLivreApplication = produto.MercadoLivreApplication.Id,
                    UrlProduto = produto.IdMercadoLivre,
                    Nome = detalheProdutoPai.Nome,
                    Quantidade = detalheProdutoPai.Quantidade,
                    IsEdicao = true,
                    NomeConta = produto.MercadoLivreApplication.Nome,
                    QuantidadeVariacoes = variacoesPai.Length,
                    Id = produto.Id
                },

            };
            foreach (var filho in produto.ProdutosMercadoLivreFilhos.Where(x=>x.Ativo))
            {
                var detalheProduto = _mercadolivreService.ObterDetalheProdutoMercadoLivre(filho.IdMercadoLivre);
                var variacoes = _mercadolivreService.ObterVariacoesProduto(filho.IdMercadoLivre);

                var modelFilho = new AssociacaoProdutosItemModel
                {
                    IdMercadoLivreApplication = filho.MercadoLivreApplication.Id,
                    UrlProduto = filho.IdMercadoLivre,
                    Nome = detalheProduto.Nome,
                    Quantidade = detalheProduto.Quantidade,
                    QuantidadeVariacoes = variacoes.Length,
                    NomeConta = filho.MercadoLivreApplication.Nome,
                    IsEdicao = true,
                    Id = filho.Id
                };

                model.Filhos.Add(modelFilho);
            }

            return View("AssociacaoProdutos", model);
        }

    }
}
