﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using SoftFramework.Core.Application.DTO.Notification;
using SoftFramework.Core.Application.Servicos.Contratos;
using SoftFramework.Core.Helper;
using SoftFramework.Web.Models.MercadoLivre;

namespace SoftFramework.Web.Controllers
{
    [AllowAnonymous]
    public class NotificationController : Controller
    {
        private readonly INotificationService _notificationService;
        private readonly IEmailSender _emailSender;

        public NotificationController(INotificationService notificationService,
            IEmailSender emailSender)
        {
            _notificationService = notificationService;
            _emailSender = emailSender;
        }

        [AllowAnonymous]
        [HttpPost]
        public JsonResult CallbackNotification(NotificationCallbackModel model)
        {
            try
            {
                var dto = Mapper.Map<NotificationDto>(model);
                _notificationService.HandleNotification(dto);
                return Json(new {message = "tks"}, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Constantes.LogarErro(ex);
                _emailSender.EnviarEmailErro(ex);
                throw;
            }
        }

    }
}
