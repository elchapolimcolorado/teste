﻿using System.Web;
using SoftFramework.Core.Domain.ObjetosValor;
using SoftFramework.Core.Infra.InjecaoDependencia;
using SoftFramework.Core.Infra.UnidadeDeTrabalho;
using SoftFramework.Web.Helpers;
using System.Web.Mvc;
using System.Web.Security;
using SoftFramework.Core.Infra.Repositorios.Contracts;

namespace SoftFramework.Web.Filters
{
    public class PermissaoAcessoAttribute : ActionFilterAttribute 
    {
        private IUnidadeDeTrabalho _unidadeDeTrabalho;
        private IRepositorioUsuario _repositorioUsuario;

        
        private void Inicializar()
        {
            _unidadeDeTrabalho = Fabrica.Instancia.Obter<IUnidadeDeTrabalho>();
            _repositorioUsuario = Fabrica.Instancia.ObterRepositorio<IRepositorioUsuario>(_unidadeDeTrabalho);
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            Inicializar();

            if (!filterContext.HttpContext.User.Identity.IsAuthenticated || ConstantesWeb.Usuario == null)
            {
                FormsAuthentication.RedirectToLoginPage();
                return;
            }
            //var usuario = _repositorioUsuario.ObterPorId(ConstantesWeb.Usuario.IdUsuario);
            //var possuiPermissao = true;
            //_unidadeDeTrabalho.Salvar();
            //_unidadeDeTrabalho.Inicializar();

            //if (!possuiPermissao)
            //{
            //    HttpContext.Current.Session["UrlRetorno"] = HttpContext.Current.Request.UrlReferrer;
            //    HttpContext.Current.Response.RedirectPermanent("~/Erro/Http403", true);
            //}

        }
        
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            
        }


    }
}