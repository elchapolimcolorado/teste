﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;
using SoftFramework.Core.Infra.InjecaoDependencia;
using SoftFramework.Web.Controllers;
using System.Web.Security;
using log4net;
using Castle.Windsor;
using Microsoft.Practices.ServiceLocation;
using SoftFramework.Core.Infra;
using SoftFramework.Web.ModelBinders;

namespace SoftFramework.Web
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801
    public class MvcApplication : System.Web.HttpApplication
    {
        private ILog Logger;
        protected void Application_Start()
        {
            
            log4net.Config.XmlConfigurator.Configure();
            AreaRegistration.RegisterAllAreas();

            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);

            RegisterRoutes(RouteTable.Routes);

            System.Web.Mvc.ModelBinders.Binders.DefaultBinder = new JsonModelBinder();
            System.Web.Mvc.ModelBinders.Binders.Add(typeof(Guid), new GuidModelBinder());
            
        }


        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.IgnoreRoute("{*favicon}", new { favicon = @"(.*/)?favicon.ico(/.*)?" });

            routes.MapRoute(
            "Default",
            "{controller}/{action}/{id}",
            new { controller = "Home", action = "Index", id = "" }
        );
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();
            this.Logger = log4net.LogManager.GetLogger("Logger");
            Logger.Error(exception);
          
        }
        
        protected void Application_End()
        {
            var container = Fabrica.Instancia.Container;

            if (container != null)
                container.Dispose();
        }

    }
}