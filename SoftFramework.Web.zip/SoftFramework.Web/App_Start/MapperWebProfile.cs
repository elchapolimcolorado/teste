﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using SoftFramework.Core.Application.DTO.Notification;
using SoftFramework.Core.Application.DTO.Produto;
using SoftFramework.Web.Models.MercadoLivre;

namespace SoftFramework.Web.App_Start
{
    public class MapperWebProfile : Profile
    {
        protected override void Configure()
        {
            base.Configure();
            Mapper.CreateMap<NotificationCallbackModel, NotificationDto>();
            Mapper.CreateMap<AssociacaoProdutosItemModel, AssociacaoProdutosItemDTO>();
            Mapper.CreateMap<AssociacaoProdutosModel, AssociacaoProdutosDTO>();
            Mapper.CreateMap<AssociacaoProdutoRetornoDTO, AssociacaoProdutoRetornoModel>();
        }
    }
}