﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SoftFramework.Web.CustomException
{
    public class FuncionarioNaoLocalizadoException : Exception
    {
    }
}